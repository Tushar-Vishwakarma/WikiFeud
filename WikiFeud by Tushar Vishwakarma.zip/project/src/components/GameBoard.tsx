import React, { useState, useEffect } from 'react';
import { searchQueries } from '../data/searchData';
import { Search } from 'lucide-react';

export default function GameBoard() {
  const [currentQueryIndex, setCurrentQueryIndex] = useState(0);
  const [userGuess, setUserGuess] = useState('');
  const [revealedAnswers, setRevealedAnswers] = useState<Set<string>>(new Set());
  const [score, setScore] = useState(0);
  const [strikes, setStrikes] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [timer, setTimer] = useState(30);
  const [showError, setShowError] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const currentQuery = searchQueries[currentQueryIndex];

  useEffect(() => {
    if (timer > 0 && !gameOver) {
      const countdown = setInterval(() => setTimer(t => t - 1), 1000);
      return () => clearInterval(countdown);
    } else if (timer === 0) {
      setGameOver(true);
    }
  }, [timer, gameOver]);

  const handleGuess = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedGuess = userGuess.toLowerCase().trim();
    const matchingCompletion = currentQuery.completions.find(
      c => c.completion.toLowerCase() === normalizedGuess
    );

    if (matchingCompletion && !revealedAnswers.has(matchingCompletion.completion)) {
      setRevealedAnswers(prev => new Set([...prev, matchingCompletion.completion]));
      setScore(prev => prev + matchingCompletion.points);
      setShowError(false);
      setIsCorrect(true);
      setTimeout(() => setIsCorrect(false), 1000);

      if (revealedAnswers.size === currentQuery.completions.length - 1) {
        setTimeout(() => nextQuestion(), 1500);
      }
    } else {
      setStrikes(prev => {
        const newStrikes = prev + 1;
        if (newStrikes >= 3) {
          setGameOver(true);
          const allAnswers = new Set(currentQuery.completions.map(c => c.completion));
          setRevealedAnswers(allAnswers);
        }
        return newStrikes;
      });
      setShowError(true);
      setTimeout(() => setShowError(false), 1000);
    }
    setUserGuess('');
  };

  const nextQuestion = () => {
    if (currentQueryIndex < searchQueries.length - 1) {
      setCurrentQueryIndex(prev => prev + 1);
      setRevealedAnswers(new Set());
      setTimer(30);
      setShowError(false);
      setIsCorrect(false);
    } else {
      setGameOver(true);
      const allAnswers = new Set(currentQuery.completions.map(c => c.completion));
      setRevealedAnswers(allAnswers);
    }
  };

  const resetGame = () => {
    setCurrentQueryIndex(0);
    setRevealedAnswers(new Set());
    setScore(0);
    setStrikes(0);
    setGameOver(false);
    setTimer(30);
    setShowError(false);
    setIsCorrect(false);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-6 bg-white p-4 rounded-lg shadow-sm border border-[#a2a9b1]">
        <div className="text-2xl font-serif text-[#202122]">Score: {score}</div>
        <div className="flex items-center gap-4">
          <div className="text-xl text-[#54595d] font-serif">{timer}s</div>
          <div className="flex gap-1">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className={`w-3 h-8 rounded ${
                  i < strikes ? 'bg-[#d33]' : 'bg-[#eaecf0]'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {!gameOver ? (
        <>
          <div className="mb-8">
            <div className="relative">
              <form onSubmit={handleGuess} className="relative">
                <div className="relative">
                  <input
                    type="text"
                    value={userGuess}
                    onChange={(e) => setUserGuess(e.target.value)}
                    className={`w-full h-12 pl-12 pr-4 text-lg border rounded-lg
                      ${showError ? 'border-[#d33] animate-shake' : ''} 
                      ${isCorrect ? 'border-[#14866d]' : 'border-[#a2a9b1]'}
                      focus:outline-none focus:border-[#36c] bg-white`}
                    placeholder={currentQuery.query + "..."}
                    disabled={gameOver}
                    autoFocus
                  />
                  <Search 
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#54595d]" 
                    size={20} 
                  />
                </div>
              </form>
            </div>
          </div>

          <div className="space-y-2">
            {currentQuery.completions.map((completion, index) => (
              <div
                key={index}
                className={`flex items-center h-12 px-4 rounded-lg overflow-hidden transition-all duration-300
                  ${revealedAnswers.has(completion.completion)
                    ? 'bg-[#36c] text-white'
                    : 'bg-white border border-[#a2a9b1]'
                  }`}
              >
                <span className="w-8 font-serif font-bold">
                  {index + 1}.
                </span>
                <span className="flex-1 font-serif">
                  {revealedAnswers.has(completion.completion)
                    ? completion.completion
                    : ''}
                </span>
                {revealedAnswers.has(completion.completion) && (
                  <span className="font-serif font-bold">{completion.points}</span>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <button
              onClick={nextQuestion}
              className="px-8 py-3 bg-[#36c] text-white rounded-lg hover:bg-[#447ff5] transition-colors font-serif"
            >
              Next Question
            </button>
          </div>
        </>
      ) : (
        <div className="text-center bg-white rounded-lg p-8 border border-[#a2a9b1]">
          <h2 className="text-3xl font-serif font-bold mb-4 text-[#202122]">Game Over!</h2>
          <p className="text-2xl mb-6 text-[#54595d] font-serif">Final Score: {score}</p>
          <button
            onClick={resetGame}
            className="px-8 py-3 bg-[#36c] text-white rounded-lg hover:bg-[#447ff5] transition-colors font-serif"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
}