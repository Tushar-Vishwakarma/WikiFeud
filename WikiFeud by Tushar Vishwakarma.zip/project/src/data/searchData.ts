interface SearchCompletion {
  completion: string;
  points: number;
}

interface SearchQuery {
  query: string;
  completions: SearchCompletion[];
}

export const searchQueries: SearchQuery[] = [
  {
    query: "how to bake a",
    completions: [
      { completion: "cake", points: 100 },
      { completion: "potato", points: 85 },
      { completion: "chicken", points: 70 },
      { completion: "pie", points: 55 },
      { completion: "bread", points: 40 }
    ]
  },
  {
    query: "best way to learn",
    completions: [
      { completion: "programming", points: 100 },
      { completion: "english", points: 85 },
      { completion: "guitar", points: 70 },
      { completion: "spanish", points: 55 },
      { completion: "math", points: 40 }
    ]
  },
  {
    query: "how to fix a",
    completions: [
      { completion: "leaky faucet", points: 100 },
      { completion: "flat tire", points: 85 },
      { completion: "broken phone", points: 70 },
      { completion: "door handle", points: 55 },
      { completion: "broken zipper", points: 40 }
    ]
  },
  {
    query: "what to do when",
    completions: [
      { completion: "bored", points: 100 },
      { completion: "sick", points: 85 },
      { completion: "stressed", points: 70 },
      { completion: "lonely", points: 55 },
      { completion: "tired", points: 40 }
    ]
  },
  {
    query: "where to find",
    completions: [
      { completion: "cheap flights", points: 100 },
      { completion: "free wifi", points: 85 },
      { completion: "my phone", points: 70 },
      { completion: "good restaurants", points: 55 },
      { completion: "parking", points: 40 }
    ]
  }
];