import React from 'react';
import GameBoard from './components/GameBoard';
import { BookOpen } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-[#f8f9fa]">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-2">
            <BookOpen size={32} className="text-[#36c]" />
            <h1 className="text-4xl font-serif">
              <span className="text-[#36c]">Wiki</span>
              <span className="text-[#202122]">Feud</span>
            </h1>
          </div>
          <p className="text-[#54595d] text-lg font-serif">
            Guess the most popular Wikipedia search completions
          </p>
        </header>
        
        <GameBoard />
      </div>
    </div>
  );
}